package com.backend.taskmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.backend.taskmanagement.entity.Task;
import com.backend.taskmanagement.payload.TaskDto;
import com.backend.taskmanagement.service.TaskService;

@RestController
@RequestMapping("/v2/api")
public class TaskController {
	
	@Autowired
	TaskService taskService;
	
	//save task
	@PostMapping("/{userId}/tasks/add")
	public ResponseEntity<TaskDto> saveTask(@RequestBody TaskDto taskDto,@PathVariable long userId) {
		return new ResponseEntity<>(taskService.saveTask(taskDto, userId),HttpStatus.CREATED);
	}
	
	//get all tasks
	@GetMapping("/{userId}/tasks")
	public ResponseEntity<List<TaskDto>> getAllTasks(@PathVariable long userId){
		return new ResponseEntity<>(taskService.getAllTasks(userId),HttpStatus.OK);
	}
	
	
	//get task based on user id
	@GetMapping("/{userId}/tasks/{taskId}")
	public ResponseEntity<TaskDto> getTaskByUserId(@PathVariable long userId,@PathVariable long taskId){
		return new ResponseEntity<>(taskService.getTask(userId, taskId),HttpStatus.OK);
	}
	
	
	//delete task
	@DeleteMapping("/{userid}/tasks/{taskid}")
	public ResponseEntity<String> deleteTask(@PathVariable long userid,@PathVariable long taskid){
		taskService.DeleteTask(userid, taskid);
		return new ResponseEntity<>("Task Deleted SuccessFully",HttpStatus.OK);
	}

}
