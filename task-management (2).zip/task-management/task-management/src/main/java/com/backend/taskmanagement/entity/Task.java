package com.backend.taskmanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="task")
public class Task {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="taskname",nullable=false)
	private String taskname;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="users_id")
	private Users user;
	
	

	public Task(long id, String taskname, Users user) {
		super();
		this.id = id;
		this.taskname = taskname;
		this.user = user;
	}
	
	public Task() {
		super();
		
	}

	public long getId() {
		return id;
	}

	public String getTaskname() {
		return taskname;
	}

	public Users getUser() {
		return user;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", taskname=" + taskname + ", user=" + user + "]";
	}
	
	

}
