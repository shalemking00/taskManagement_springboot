package com.backend.taskmanagement.payload;

public class TaskDto {
	
	private long id;
	private String taskname;
	
	public long getId() {
		return id;
	}
	public String getTaskname() {
		return taskname;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}

}
