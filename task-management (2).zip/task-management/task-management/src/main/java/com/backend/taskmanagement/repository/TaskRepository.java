package com.backend.taskmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.backend.taskmanagement.entity.Task;
import com.backend.taskmanagement.payload.TaskDto;

@Repository
public interface TaskRepository extends JpaRepository<Task,Long> {

	List<Task> findAllByUserId(long id);

}
