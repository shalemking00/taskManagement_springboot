package com.backend.taskmanagement.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.backend.taskmanagement.entity.Users;
import com.backend.taskmanagement.exception.UserNotFound;
import com.backend.taskmanagement.repository.UserRepository;

public class CustomUserDetailsService implements UserDetailsService {
	
	@Autowired
	UserRepository userRepo;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Users user=userRepo.findByEmail(email).orElseThrow(()->new UserNotFound(String.format("User with email: %s is not present", email)));
		
		return null;
	}

}
