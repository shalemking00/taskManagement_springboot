package com.backend.taskmanagement.service;

import java.util.List;


import com.backend.taskmanagement.payload.TaskDto;

public interface TaskService {
	
	public TaskDto saveTask(TaskDto taskDto,long id);
	
	public List<TaskDto> getAllTasks(long id);
	
	public TaskDto getTask(long userid,long taskId);
	
	public void DeleteTask(long userid,long taskId);

}
