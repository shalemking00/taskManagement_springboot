package com.backend.taskmanagement.service;

import com.backend.taskmanagement.payload.UserDto;

public interface UserService {
	
	public UserDto createUser(UserDto userDto);

}
