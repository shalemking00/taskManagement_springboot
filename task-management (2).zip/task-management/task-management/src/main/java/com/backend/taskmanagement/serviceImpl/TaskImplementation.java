package com.backend.taskmanagement.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backend.taskmanagement.entity.Task;
import com.backend.taskmanagement.entity.Users;
import com.backend.taskmanagement.exception.APIException;
import com.backend.taskmanagement.exception.TaskNotFound;
import com.backend.taskmanagement.exception.UserNotFound;
import com.backend.taskmanagement.payload.TaskDto;
import com.backend.taskmanagement.repository.TaskRepository;
import com.backend.taskmanagement.repository.UserRepository;
import com.backend.taskmanagement.service.TaskService;

@Service
public class TaskImplementation implements TaskService {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	UserRepository userRepo;
	@Autowired
	TaskRepository taskRepo;
	
	
	@Override
	public TaskDto saveTask(TaskDto taskDto, long id) {
		Users user=userRepo.findById(id).orElseThrow(() -> new UserNotFound(String.format("user Id %d is not found",id)));
		Task task=modelMapper.map(taskDto, Task.class);
		task.setUser(user);
		taskRepo.save(task);
		return modelMapper.map(task,TaskDto.class);
	}

	@Override
	public List<TaskDto> getAllTasks(long id) {
		userRepo.findById(id).orElseThrow(() -> new UserNotFound(String.format("user Id %d is not found",id)));
		List<Task> tasks=taskRepo.findAllByUserId(id);
		return tasks.stream().map(task -> modelMapper.map(task, TaskDto.class)).collect(Collectors.toList());
	}

	@Override
	public TaskDto getTask(long userid, long taskId) {
		Users users=userRepo.findById(userid).orElseThrow(() -> new UserNotFound(String.format("user Id %d is not found",userid)));
		Task task=taskRepo.findById(taskId).orElseThrow(() -> new TaskNotFound(String.format("task Id %d is not found",taskId)));
		if(users.getId()!=task.getUser().getId()) {
			throw new APIException(String.format("Task Id %d is not belongs to User Id %d",taskId,userid));
		}
		return modelMapper.map(task, TaskDto.class);
	}

	@Override
	public void DeleteTask(long userid, long taskId) {
		Users users=userRepo.findById(userid).orElseThrow(() -> new UserNotFound(String.format("user Id %d is not found",userid)));
		Task task=taskRepo.findById(taskId).orElseThrow(() -> new TaskNotFound(String.format("task Id %d is not found",taskId)));
		if(users.getId()!=task.getUser().getId()) {
			throw new APIException(String.format("Task Id %d is not belongs to User Id %d",taskId,userid));
		}
		taskRepo.deleteById(taskId);
	}

}
