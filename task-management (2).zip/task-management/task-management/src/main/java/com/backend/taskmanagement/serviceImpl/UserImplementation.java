package com.backend.taskmanagement.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backend.taskmanagement.entity.Users;
import com.backend.taskmanagement.payload.UserDto;
import com.backend.taskmanagement.repository.UserRepository;
import com.backend.taskmanagement.service.UserService;

@Service
public class UserImplementation implements UserService {
	
	@Autowired
	UserRepository userRepo;

	@Override
	public UserDto createUser(UserDto userDto) {
		Users user=userDtoToEntity(userDto);
		Users savedUser=userRepo.save(user);
		return entityTouserDto(savedUser);
	}
	
	private Users userDtoToEntity(UserDto userDto) {
		Users user=new Users();
		user.setName(userDto.getName());
		user.setEmail(userDto.getEmail());
		user.setPassword(userDto.getPassword());
		return user;
	}
	
	private UserDto entityTouserDto(Users savedUser) {
		UserDto user=new UserDto();
		user.setId(savedUser.getId());
		user.setName(savedUser.getName());
		user.setEmail(savedUser.getEmail());
		user.setPassword(savedUser.getPassword());
		return user;
	}

}
